# GCP FinOps Reporting (Cloudability-like) - Starter Kit

Contains:
- `backend/` FastAPI + Postgres saved reports + BigQuery execution
- `frontend/` Next.js UI

## Start Postgres
```bash
docker compose up -d
```

## Backend
```bash
cd backend
cp .env.example .env
# set GCP_PROJECT_ID + BQ_DEFAULT_VIEW_FQN
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## Frontend
```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Open:
- UI: http://localhost:3000
- API docs: http://localhost:8000/docs
