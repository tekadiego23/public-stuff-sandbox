# Backend (FastAPI)

## Quickstart (local)
1) Create and activate a venv
2) Install deps:
```bash
pip install -r requirements.txt
```

3) Configure env vars (see `.env.example`)
4) Run:
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Notes
- Postgres stores saved reports/configs + run history.
- BigQuery runs the analytics queries.
- Cloudability `Account Name` is mapped to `account_id = project.id`.
