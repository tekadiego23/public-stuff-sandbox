from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from .catalog import DIMENSIONS, METRICS

@dataclass
class BuiltQuery:
    sql: str
    params: Dict[str, Any]
    output_columns: List[str]

def build_bq_query(
    view_fqn: str,
    date_from: str,
    date_to: str,
    dimensions: List[str],
    metrics: List[str],
    filters: Optional[List[dict]] = None,
    sort: Optional[List[dict]] = None,
    limit: Optional[int] = 5000,
) -> BuiltQuery:
    dim_exprs = []
    group_by_exprs = []
    output_columns: List[str] = []

    for d in dimensions:
        if d not in DIMENSIONS:
            raise ValueError(f"Unknown dimension: {d}")
        expr = DIMENSIONS[d]
        dim_exprs.append(f"{expr} AS {d}")
        group_by_exprs.append(expr)
        output_columns.append(d)

    metric_exprs = []
    for m in metrics:
        if m not in METRICS:
            raise ValueError(f"Unknown metric: {m}")
        metric_exprs.append(f"{METRICS[m]} AS {m}")
        output_columns.append(m)

    if not (dim_exprs or metric_exprs):
        raise ValueError("At least one dimension or metric is required.")

    where_clauses = ["usage_date BETWEEN @date_from AND @date_to"]
    params: Dict[str, Any] = {"date_from": date_from, "date_to": date_to}

    if filters:
        for i, f in enumerate(filters):
            field = f.get("field")
            op = str(f.get("op", "")).upper()
            value = f.get("value")

            if field not in DIMENSIONS:
                raise ValueError(f"Filter field not allowed: {field}")

            col = DIMENSIONS[field]
            p = f"p{i}"

            if op in ("=", "!=", "LIKE"):
                where_clauses.append(f"{col} {op} @{p}")
                params[p] = value
            elif op in ("IN", "NOT IN"):
                where_clauses.append(f"{col} {op} UNNEST(@{p})")
                params[p] = value
            else:
                raise ValueError(f"Unsupported operator: {op}")

    sql = f"""SELECT
  {", ".join(dim_exprs + metric_exprs)}
FROM `{view_fqn}`
WHERE {" AND ".join(where_clauses)}
"""

    if group_by_exprs and metric_exprs:
        sql += f"\nGROUP BY {', '.join(group_by_exprs)}"

    if sort:
        order_parts = []
        for s in sort:
            sf = s.get("field")
            direction = str(s.get("direction", "ASC")).upper()
            if sf not in DIMENSIONS and sf not in METRICS:
                raise ValueError(f"Sort field not allowed: {sf}")
            if direction not in ("ASC", "DESC"):
                raise ValueError("Sort direction must be ASC or DESC")
            order_parts.append(f"{sf} {direction}")
        if order_parts:
            sql += f"\nORDER BY {', '.join(order_parts)}"

    if limit:
        sql += "\nLIMIT @limit"
        params["limit"] = int(limit)

    return BuiltQuery(sql=sql.strip(), params=params, output_columns=output_columns)
