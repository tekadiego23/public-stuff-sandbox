DIMENSIONS = {
    "usage_date": "usage_date",
    "account_id": "account_id",
    "account_name": "account_name",
    "service": "service",
    "sku": "sku",
    "region": "region",
    "resource_name": "resource_name",
    "environment_label_key": "environment_label_key",
    "environment_label_value": "environment_label_value",
}

METRICS = {
    "cost_csp_total": "SUM(cost_csp_total)",
}

CATALOG = {
    "dimensions": [{"key": k, "sql": v} for k, v in DIMENSIONS.items()],
    "metrics": [{"key": k, "sql": v} for k, v in METRICS.items()],
}
