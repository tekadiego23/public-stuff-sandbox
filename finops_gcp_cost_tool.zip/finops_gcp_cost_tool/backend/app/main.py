from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from uuid import UUID
from .settings import settings
from .db import get_engine
from .models import Base
from .schemas import ReportCreate, ReportOut, ReportUpdate, QueryResult, RunOut
from .catalog import CATALOG
from .query_builder import build_bq_query
from .bq import run_query
from . import crud

app = FastAPI(title="GCP FinOps Reporting API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if settings.create_tables:
    Base.metadata.create_all(bind=get_engine())

def _db() -> Session:
    return Session(get_engine())

def _report_to_out(r) -> ReportOut:
    return ReportOut(
        id=r.id,
        name=r.name,
        description=r.description,
        created_by=r.created_by,
        config=r.config,
        created_at=r.created_at.isoformat(),
        updated_at=r.updated_at.isoformat(),
    )

def _run_to_out(run) -> RunOut:
    return RunOut(
        id=run.id,
        report_id=run.report_id,
        status=run.status,
        started_at=run.started_at.isoformat(),
        finished_at=run.finished_at.isoformat() if run.finished_at else None,
        row_count=run.row_count,
        bq_job_id=run.bq_job_id,
        error=run.error,
        result_preview=run.result_preview,
    )

@app.get("/healthz")
def healthz():
    return {"ok": True}

@app.get("/catalog")
def catalog():
    return CATALOG

@app.get("/reports", response_model=list[ReportOut])
def list_reports():
    with _db() as db:
        reports = crud.list_reports(db)
        return [_report_to_out(r) for r in reports]

@app.post("/reports", response_model=ReportOut)
def create_report(payload: ReportCreate):
    with _db() as db:
        r = crud.create_report(
            db,
            name=payload.name,
            description=payload.description,
            created_by=payload.created_by,
            config=payload.config.model_dump(by_alias=True),
        )
        return _report_to_out(r)

@app.get("/reports/{report_id}", response_model=ReportOut)
def get_report(report_id: UUID):
    with _db() as db:
        r = crud.get_report(db, report_id)
        if not r:
            raise HTTPException(status_code=404, detail="Report not found")
        return _report_to_out(r)

@app.patch("/reports/{report_id}", response_model=ReportOut)
def update_report(report_id: UUID, payload: ReportUpdate):
    with _db() as db:
        r = crud.update_report(
            db,
            report_id,
            name=payload.name,
            description=payload.description,
            config=payload.config.model_dump(by_alias=True) if payload.config else None,
        )
        if not r:
            raise HTTPException(status_code=404, detail="Report not found")
        return _report_to_out(r)

@app.delete("/reports/{report_id}")
def delete_report(report_id: UUID):
    with _db() as db:
        ok = crud.delete_report(db, report_id)
        if not ok:
            raise HTTPException(status_code=404, detail="Report not found")
        return {"deleted": True}

@app.get("/reports/{report_id}/runs", response_model=list[RunOut])
def list_runs(report_id: UUID, limit: int = 20):
    with _db() as db:
        r = crud.get_report(db, report_id)
        if not r:
            raise HTTPException(status_code=404, detail="Report not found")
        runs = crud.list_runs(db, report_id, limit=limit)
        return [_run_to_out(x) for x in runs]

@app.post("/reports/{report_id}/run", response_model=QueryResult)
def run_report(report_id: UUID, preview_rows: int = 200):
    with _db() as db:
        report = crud.get_report(db, report_id)
        if not report:
            raise HTTPException(status_code=404, detail="Report not found")
        run = crud.create_run(db, report_id)

        try:
            cfg = report.config
            date_range = cfg.get("date_range") or {}
            date_from = date_range.get("from")
            date_to = date_range.get("to")
            if not date_from or not date_to:
                raise ValueError("date_range.from and date_range.to are required")

            view_fqn = cfg.get("dataset_view") or settings.bq_default_view_fqn
            if not view_fqn:
                raise ValueError("No dataset_view provided and BQ_DEFAULT_VIEW_FQN is not configured")

            built = build_bq_query(
                view_fqn=view_fqn,
                date_from=date_from,
                date_to=date_to,
                dimensions=cfg.get("dimensions", []),
                metrics=cfg.get("metrics", []),
                filters=cfg.get("filters", []),
                sort=cfg.get("sort", []),
                limit=cfg.get("limit", 5000),
            )

            bq_job_id, rows = run_query(built.sql, built.params, max_rows=min(cfg.get("limit", 5000), 5000))

            columns = built.output_columns
            out_rows = [[r.get(c) for c in columns] for r in rows]

            preview = {"columns": columns, "rows": out_rows[:max(0, int(preview_rows))]}
            crud.finish_run_success(db, run.id, bq_job_id=bq_job_id, row_count=len(rows), preview=preview)

            return {"columns": columns, "rows": out_rows}

        except Exception as e:
            crud.finish_run_failed(db, run.id, error=str(e))
            raise HTTPException(status_code=400, detail=str(e))
