from sqlalchemy import select
from sqlalchemy.orm import Session
from uuid import UUID
from .models import Report, ReportRun
from datetime import datetime, timezone

def list_reports(db: Session) -> list[Report]:
    return db.execute(select(Report).order_by(Report.updated_at.desc())).scalars().all()

def get_report(db: Session, report_id: UUID) -> Report | None:
    return db.get(Report, report_id)

def create_report(db: Session, *, name: str, description: str | None, created_by: str | None, config: dict) -> Report:
    r = Report(name=name, description=description, created_by=created_by, config=config)
    db.add(r)
    db.commit()
    db.refresh(r)
    return r

def update_report(db: Session, report_id: UUID, *, name: str | None, description: str | None, config: dict | None) -> Report | None:
    r = db.get(Report, report_id)
    if not r:
        return None
    if name is not None:
        r.name = name
    if description is not None:
        r.description = description
    if config is not None:
        r.config = config
    db.commit()
    db.refresh(r)
    return r

def delete_report(db: Session, report_id: UUID) -> bool:
    r = db.get(Report, report_id)
    if not r:
        return False
    db.delete(r)
    db.commit()
    return True

def create_run(db: Session, report_id: UUID) -> ReportRun:
    run = ReportRun(report_id=report_id, status="running")
    db.add(run)
    db.commit()
    db.refresh(run)
    return run

def finish_run_success(db: Session, run_id: UUID, *, bq_job_id: str, row_count: int, preview: dict):
    run = db.get(ReportRun, run_id)
    if not run:
        return
    run.status = "success"
    run.finished_at = datetime.now(timezone.utc)
    run.bq_job_id = bq_job_id
    run.row_count = row_count
    run.result_preview = preview
    db.commit()

def finish_run_failed(db: Session, run_id: UUID, *, error: str):
    run = db.get(ReportRun, run_id)
    if not run:
        return
    run.status = "failed"
    run.finished_at = datetime.now(timezone.utc)
    run.error = error
    db.commit()

def list_runs(db: Session, report_id: UUID, limit: int = 20) -> list[ReportRun]:
    return db.execute(
        select(ReportRun)
        .where(ReportRun.report_id == report_id)
        .order_by(ReportRun.started_at.desc())
        .limit(limit)
    ).scalars().all()
