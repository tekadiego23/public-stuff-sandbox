from pydantic import BaseModel, Field
from typing import Any, List, Optional, Literal
from uuid import UUID

class Filter(BaseModel):
    field: str
    op: Literal["=", "!=", "IN", "NOT IN", "LIKE"]
    value: Any

class Sort(BaseModel):
    field: str
    direction: Literal["ASC", "DESC"] = "ASC"

class DateRange(BaseModel):
    from_: str = Field(alias="from")
    to: str

class ReportConfig(BaseModel):
    date_range: DateRange
    dataset_view: Optional[str] = None
    dimensions: List[str] = Field(default_factory=list)
    metrics: List[str] = Field(default_factory=list)
    filters: List[Filter] = Field(default_factory=list)
    sort: List[Sort] = Field(default_factory=list)
    limit: Optional[int] = 5000

class ReportCreate(BaseModel):
    name: str
    description: Optional[str] = None
    created_by: Optional[str] = None
    config: ReportConfig

class ReportUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    config: Optional[ReportConfig] = None

class ReportOut(BaseModel):
    id: UUID
    name: str
    description: Optional[str] = None
    created_by: Optional[str] = None
    config: dict
    created_at: str
    updated_at: str

class RunOut(BaseModel):
    id: UUID
    report_id: UUID
    status: str
    started_at: str
    finished_at: Optional[str] = None
    row_count: Optional[int] = None
    bq_job_id: Optional[str] = None
    error: Optional[str] = None
    result_preview: Optional[dict] = None

class QueryResult(BaseModel):
    columns: List[str]
    rows: List[list]
