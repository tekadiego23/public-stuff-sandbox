from typing import Any, Dict, List, Tuple
from google.cloud import bigquery
from .settings import settings

_client: bigquery.Client | None = None

def get_bq_client() -> bigquery.Client:
    global _client
    if _client is None:
        _client = bigquery.Client(project=settings.gcp_project_id or None, location=settings.bq_location)
    return _client

def _to_query_parameters(params: Dict[str, Any]) -> List[bigquery.ScalarQueryParameter | bigquery.ArrayQueryParameter]:
    out: List[Any] = []
    for k, v in params.items():
        if isinstance(v, list):
            elem_type = "STRING"
            if v:
                if isinstance(v[0], int):
                    elem_type = "INT64"
                elif isinstance(v[0], float):
                    elem_type = "FLOAT64"
                elif isinstance(v[0], bool):
                    elem_type = "BOOL"
            out.append(bigquery.ArrayQueryParameter(k, elem_type, v))
        else:
            t = "STRING"
            if isinstance(v, int):
                t = "INT64"
            elif isinstance(v, float):
                t = "FLOAT64"
            elif isinstance(v, bool):
                t = "BOOL"
            out.append(bigquery.ScalarQueryParameter(k, t, v))
    return out

def run_query(sql: str, params: Dict[str, Any], max_rows: int = 5000) -> Tuple[str, List[dict]]:
    client = get_bq_client()
    job_config = bigquery.QueryJobConfig(query_parameters=_to_query_parameters(params))
    job = client.query(sql, job_config=job_config)
    rows_iter = job.result(page_size=min(1000, max_rows))
    rows: List[dict] = []
    for i, row in enumerate(rows_iter):
        if i >= max_rows:
            break
        rows.append(dict(row.items()))
    return job.job_id, rows
