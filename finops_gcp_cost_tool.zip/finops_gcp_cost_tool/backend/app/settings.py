from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg2://postgres:postgres@localhost:5432/finops"

    gcp_project_id: str = ""
    bq_default_view_fqn: str = ""
    bq_location: str = "EU"

    cors_origins: str = "http://localhost:3000"
    create_tables: int = 0

    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

settings = Settings()
