import useSWR from "swr";
import Link from "next/link";
import { apiGet, apiPost } from "../lib/api";
import type { Report } from "../types/finops";

const fetcher = (path: string) => apiGet<any>(path);

export default function Home() {
  const { data, error, mutate } = useSWR<Report[]>("/reports", fetcher);

  async function createExample() {
    const today = new Date();
    const to = today.toISOString().slice(0, 10);
    const from = new Date(today.getTime() - 6 * 86400000).toISOString().slice(0, 10);

    const payload = {
      name: "Daily Report by Project (MVP)",
      description: "Date + Account (project.id) + Env label (key/value) + CSP Total",
      created_by: "internal",
      config: {
        date_range: { from, to },
        dimensions: ["usage_date", "account_id", "environment_label_key", "environment_label_value"],
        metrics: ["cost_csp_total"],
        filters: [],
        sort: [{ field: "usage_date", direction: "DESC" }],
        limit: 2000
      },
    };

    await apiPost("/reports", payload);
    mutate();
  }

  if (error) return <div style={{ padding: 24 }}>Error: {String(error)}</div>;
  if (!data) return <div style={{ padding: 24 }}>Loading…</div>;

  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>FinOps Reports</h1>
      <p>
        <button onClick={createExample}>Create example report</button>{" "}
        <Link href="/builder">Go to builder</Link>
      </p>

      <ul>
        {data.map((r) => (
          <li key={r.id} style={{ marginBottom: 10 }}>
            <b>{r.name}</b>{" "}
            <Link href={`/reports/${r.id}`}>Open</Link>
            <div style={{ color: "#666" }}>{r.description}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
