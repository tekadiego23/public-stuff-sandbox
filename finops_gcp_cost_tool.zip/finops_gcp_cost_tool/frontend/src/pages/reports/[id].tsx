import { useRouter } from "next/router";
import useSWR from "swr";
import { apiGet, apiPost, apiDelete } from "../../lib/api";
import type { Report, QueryResult } from "../../types/finops";
import { useState } from "react";

const fetcher = (path: string) => apiGet<any>(path);

function Table({ result }: { result: QueryResult }) {
  return (
    <div style={{ overflow: "auto", border: "1px solid #ddd" }}>
      <table cellPadding={6} style={{ borderCollapse: "collapse", width: "100%" }}>
        <thead>
          <tr>
            {result.columns.map((c) => (
              <th key={c} style={{ textAlign: "left", borderBottom: "1px solid #ddd", whiteSpace: "nowrap" }}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {result.rows.map((r, idx) => (
            <tr key={idx}>
              {r.map((v: any, j: number) => (
                <td key={j} style={{ borderBottom: "1px solid #f0f0f0", whiteSpace: "nowrap" }}>
                  {v === null || v === undefined ? "" : String(v)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function ReportPage() {
  const router = useRouter();
  const id = router.query.id as string | undefined;

  const { data: report, error } = useSWR<Report>(id ? `/reports/${id}` : null, fetcher);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!id) return;
    setRunning(true);
    try {
      const res = await apiPost<QueryResult>(`/reports/${id}/run`, {});
      setResult(res);
    } finally {
      setRunning(false);
    }
  }

  async function remove() {
    if (!id) return;
    if (!confirm("Delete this report?")) return;
    await apiDelete(`/reports/${id}`);
    router.push("/");
  }

  if (error) return <div style={{ padding: 24 }}>Error: {String(error)}</div>;
  if (!report) return <div style={{ padding: 24 }}>Loading…</div>;

  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <p><a href="/">← Back</a></p>
      <h1>{report.name}</h1>
      <div style={{ color: "#666" }}>{report.description}</div>

      <p style={{ marginTop: 12 }}>
        <button onClick={run} disabled={running}>{running ? "Running…" : "Run"}</button>{" "}
        <button onClick={remove} style={{ marginLeft: 8 }}>Delete</button>
      </p>

      <h3>Config</h3>
      <pre style={{ background: "#f6f6f6", padding: 12, overflow: "auto" }}>
        {JSON.stringify(report.config, null, 2)}
      </pre>

      {result && (
        <>
          <h3>Result</h3>
          <Table result={result} />
        </>
      )}
    </div>
  );
}
