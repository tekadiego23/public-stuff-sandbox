import { useEffect, useMemo, useState } from "react";
import { apiGet, apiPost } from "../lib/api";
import type { Catalog, ReportConfig } from "../types/finops";

export default function Builder() {
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [name, setName] = useState("New Report");
  const [description, setDescription] = useState("");
  const [from, setFrom] = useState(new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10));
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));

  const [dimensions, setDimensions] = useState<string[]>(["usage_date", "account_id"]);
  const [metrics, setMetrics] = useState<string[]>(["cost_csp_total"]);

  const [accountIds, setAccountIds] = useState<string>("");
  const [envValue, setEnvValue] = useState<string>("");

  useEffect(() => {
    apiGet<Catalog>("/catalog").then(setCatalog).catch(console.error);
  }, []);

  const filters = useMemo(() => {
    const out: any[] = [];
    const ids = accountIds.split(",").map((s) => s.trim()).filter(Boolean);
    if (ids.length) out.push({ field: "account_id", op: "IN", value: ids });
    if (envValue.trim()) out.push({ field: "environment_label_value", op: "=", value: envValue.trim() });
    return out;
  }, [accountIds, envValue]);

  async function save() {
    const cfg: ReportConfig = {
      date_range: { from, to },
      dimensions,
      metrics,
      filters,
      sort: [{ field: "usage_date", direction: "DESC" }],
      limit: 5000,
    };

    const payload = { name, description, created_by: "internal", config: cfg };
    const created = await apiPost<any>("/reports", payload);
    alert(`Saved! Report id: ${created.id}`);
  }

  if (!catalog) return <div style={{ padding: 24 }}>Loading catalog…</div>;

  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>Report Builder (MVP)</h1>
      <p><a href="/">← Back</a></p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, maxWidth: 900 }}>
        <div>
          <label>Name</label><br/>
          <input value={name} onChange={(e) => setName(e.target.value)} style={{ width: "100%" }} />
        </div>
        <div>
          <label>Description</label><br/>
          <input value={description} onChange={(e) => setDescription(e.target.value)} style={{ width: "100%" }} />
        </div>

        <div>
          <label>Date from</label><br/>
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </div>
        <div>
          <label>Date to</label><br/>
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>

        <div>
          <label>Dimensions</label><br/>
          <select multiple value={dimensions} onChange={(e) => {
            const opts = Array.from(e.target.selectedOptions).map(o => o.value);
            setDimensions(opts);
          }} style={{ width: "100%", height: 180 }}>
            {catalog.dimensions.map(d => (
              <option key={d.key} value={d.key}>{d.key}</option>
            ))}
          </select>
        </div>

        <div>
          <label>Metrics</label><br/>
          <select multiple value={metrics} onChange={(e) => {
            const opts = Array.from(e.target.selectedOptions).map(o => o.value);
            setMetrics(opts);
          }} style={{ width: "100%", height: 180 }}>
            {catalog.metrics.map(m => (
              <option key={m.key} value={m.key}>{m.key}</option>
            ))}
          </select>
        </div>

        <div>
          <label>Filter: account_id IN (comma separated)</label><br/>
          <input value={accountIds} onChange={(e) => setAccountIds(e.target.value)} style={{ width: "100%" }} placeholder="hsbc-xxx-dev, hsbc-yyy-prod" />
        </div>

        <div>
          <label>Filter: environment_label_value =</label><br/>
          <input value={envValue} onChange={(e) => setEnvValue(e.target.value)} style={{ width: "100%" }} placeholder="prod" />
        </div>
      </div>

      <p style={{ marginTop: 16 }}>
        <button onClick={save}>Save report</button>
      </p>

      <h3>Computed config</h3>
      <pre style={{ background: "#f6f6f6", padding: 12, maxWidth: 900, overflow: "auto" }}>
{JSON.stringify({
  date_range: { from, to },
  dimensions,
  metrics,
  filters,
  sort: [{ field: "usage_date", direction: "DESC" }],
  limit: 5000
}, null, 2)}
      </pre>
    </div>
  );
}
