export type Catalog = {
  dimensions: { key: string; sql: string }[];
  metrics: { key: string; sql: string }[];
};

export type Filter = { field: string; op: "=" | "!=" | "IN" | "NOT IN" | "LIKE"; value: any };
export type Sort = { field: string; direction: "ASC" | "DESC" };

export type ReportConfig = {
  date_range: { from: string; to: string };
  dataset_view?: string | null;
  dimensions: string[];
  metrics: string[];
  filters: Filter[];
  sort: Sort[];
  limit?: number | null;
};

export type Report = {
  id: string;
  name: string;
  description?: string | null;
  created_by?: string | null;
  config: any;
  created_at: string;
  updated_at: string;
};

export type QueryResult = { columns: string[]; rows: any[][] };
